# 合并策略
[参考](https://zhuanlan.zhihu.com/p/147152207)
